<?php

namespace App\Http\Controllers;

use App\Models\Tax;
use Illuminate\Http\Request;

class TaxController extends Controller
{
    // List all taxes
    public function index()
    {
        $taxes = Tax::with(['properties', 'reservations', 'folios'])->get();
        return response()->json($taxes);
    }

    // Show a single tax with details
    public function show($id)
    {
        $tax = Tax::with(['properties', 'reservations', 'folios'])->find($id);
        return response()->json($tax);
    }

    // Create a new tax record
    public function store(Request $request)
    {
        $tax = Tax::create($request->all());
        // Additional logic for setting up tax rules and applicability
        return response()->json($tax, 201);
    }

    // Update a tax record
    public function update(Request $request, $id)
    {
        $tax = Tax::findOrFail($id);
        $tax->update($request->all());
        // Additional logic for managing tax rate changes or applicability
        return response()->json($tax, 200);
    }

    // Delete a tax record
    public function destroy($id)
    {
        Tax::find($id)->delete();
        // Additional cleanup if required, like adjusting tax applications on folios
        return response()->json(null, 204);
    }

    // Additional methods for specific operations...

    // Example: Adjusting tax rates for specific conditions or promotions
    public function adjustTaxRate($taxId, Request $request)
    {
        // Logic for adjusting a tax rate under specific conditions
    }

    // Example: Applying tax to a specific reservation or folio
    public function applyToReservation($taxId, $reservationId)
    {
        // Logic for applying a tax to a particular reservation or folio
    }

    // Example: Applying tax to specific services or folios
    public function applyTax($folioId, $taxId)
    {
        // Logic to apply a specific tax to a service or folio
    }
}

