<?php

namespace App\Http\Controllers;

use App\Models\CheckIn;
use App\Models\Reservation;
use Illuminate\Http\Request;

class CheckInController extends Controller
{
    // List all check-ins
    public function index()
    {
        $checkIns = CheckIn::with(['reservation.guest', 'reservation.room', 'user'])->get();
        return response()->json($checkIns);
    }

    // Show a single check-in record
    public function show($id)
    {
        $checkIn = CheckIn::with(['reservation.guest', 'reservation.room', 'user'])->find($id);
        return response()->json($checkIn);
    }

     // Record a new check-in
     public function store(Request $request)
     {
         // Validate the request data
         // ...

         // Check if the reservation exists and is valid for check-in
         $reservation = Reservation::find($request->reservation_id);
         if (!$reservation || $reservation->status != 'confirmed') {
             return response()->json(['message' => 'Invalid reservation for check-in'], 400);
         }

         // Create the CheckIn record
         $checkIn = CheckIn::create([
             'reservation_id' => $reservation->id,
             'user_id' => $request->user_id, // Assuming the user performing the check-in is provided
             // Other check-in details...
         ]);

         // Update the reservation status to 'checked-in'
         $reservation->update(['status' => 'checked-in']);

         // Additional logic for room assignment, guest notifications, etc.
         // ...

         return response()->json($checkIn, 201);
     }


    // Update a check-in record (e.g., modify time, handle issues)
    public function update(Request $request, $id)
    {
        $checkIn = CheckIn::findOrFail($id);
        $checkIn->update($request->all());
        // Handle additional logic as necessary
        return response()->json($checkIn, 200);
    }

    // Delete a check-in record (if needed)
    public function destroy($id)
    {
        CheckIn::find($id)->delete();
        // Handle any additional cleanup
        return response()->json(null, 204);
    }

    // Additional methods for specific operations...

    // Example: Handling early or late check-ins
    public function handleSpecialCheckIn($id, Request $request)
    {
        // Logic for managing special check-in scenarios
    }
}
