<?php

namespace App\Http\Controllers;

use App\Models\CheckOut;
use Illuminate\Http\Request;

class CheckOutController extends Controller
{
    // List all check-outs
    public function index()
    {
        $checkOuts = CheckOut::with(['reservation.guest', 'reservation.room', 'user'])->get();
        return response()->json($checkOuts);
    }

    // Show a single check-out record
    public function show($id)
    {
        $checkOut = CheckOut::with(['reservation.guest', 'reservation.room', 'user'])->find($id);
        return response()->json($checkOut);
    }

    // Record a new check-out
    public function store(Request $request)
    {
        // Validate request, ensure related reservation is in order
        $checkOut = CheckOut::create($request->all());
        // Additional logic like finalizing billing, updating room status, etc.
        return response()->json($checkOut, 201);
    }

    // Update a check-out record (e.g., handle late check-outs, billing adjustments)
    public function update(Request $request, $id)
    {
        $checkOut = CheckOut::findOrFail($id);
        $checkOut->update($request->all());
        // Additional logic for specific check-out scenarios
        return response()->json($checkOut, 200);
    }

    // Delete a check-out record (if necessary)
    public function destroy($id)
    {
        CheckOut::find($id)->delete();
        // Additional cleanup if required
        return response()->json(null, 204);
    }

    // Additional methods for specific operations...

    // Example: Finalizing billing and payments
    public function finalizeBilling($id, Request $request)
    {
        // Logic for finalizing the billing process for a check-out
    }
}
