<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class FolioChargesController extends Controller
{
    //
}
